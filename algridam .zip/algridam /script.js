// Faylka script.js
let history = []; // Array loogu talagalay taariikhda

// Dib u soo celi xogta hore haddii ay jirto
if (localStorage.getItem("calculationHistory")) {
    history = JSON.parse(localStorage.getItem("calculationHistory"));
    updateHistoryUI();
}

function calculate() {
    const num1 = parseFloat(document.getElementById('num1').value);
    const num2 = parseFloat(document.getElementById('num2').value);
    const operation = document.getElementById('operation').value;

    let result;

    if (isNaN(num1) || isNaN(num2)) {
        document.getElementById('result').innerText = "Fadlan lambarro sax ah geli!";
        return;
    }

    if (operation === "add") result = num1 + num2;
    else if (operation === "subtract") result = num1 - num2;
    else if (operation === "multiply") result = num1 * num2;
    else if (operation === "divide") {
        result = num2 !== 0 ? num1 / num2 : "Lambar laguma qaybin karo eber!";
    }

    const calculation = `${num1} ${getOperationSymbol(operation)} ${num2} = ${result}`;
    history.push(calculation);

    localStorage.setItem("calculationHistory", JSON.stringify(history));
    document.getElementById('result').innerText = result;

    updateHistoryUI();
}

function updateHistoryUI() {
    const historyList = document.getElementById('history-list');
    historyList.innerHTML = ""; // Nadiifi liiska hore

    history.forEach((item, index) => {
        const li = document.createElement('li');
        li.textContent = item;

        // Ku dar badhanka tirtiridda xogta goonida ah
        const deleteButton = document.createElement('button');
        deleteButton.textContent = "Tirtir";
        deleteButton.onclick = () => deleteHistoryItem(index);

        li.appendChild(deleteButton);
        historyList.appendChild(li);
    });
}

function deleteHistoryItem(index) {
    // Ka saar xogta index-ga la xushay
    history.splice(index, 1);

    // Dib ugu kaydi xogta updated ah localStorage
    localStorage.setItem("calculationHistory", JSON.stringify(history));

    // Dib u muuji UI-ga
    updateHistoryUI();
}

function clearAllHistory() {
    // Nadiifi array-ga history
    history = [];

    // Ka saar xogta localStorage
    localStorage.removeItem("calculationHistory");

    // Dib u muuji UI-ga
    updateHistoryUI();
}

function getOperationSymbol(operation) {
    switch (operation) {
        case "add":
            return "+";
        case "subtract":
            return "-";
        case "multiply":
            return "×";
        case "divide":
            return "÷";
        default:
            return "";
    }
}

function toggleHistory() {
    const historyDiv = document.getElementById('history');
    historyDiv.style.display = historyDiv.style.display === "none" ? "block" : "none";
}